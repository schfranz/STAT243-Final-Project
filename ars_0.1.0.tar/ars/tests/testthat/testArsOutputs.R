#tests for correctness of output given known input distributions
